<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use \Illuminate\Database\Eloquent\SoftDeletes, \Kalnoy\Nestedset\NodeTrait;
use Kalnoy\Nestedset\NodeTrait;

class Ntre extends Model
{
    //
    use NodeTrait;

}
