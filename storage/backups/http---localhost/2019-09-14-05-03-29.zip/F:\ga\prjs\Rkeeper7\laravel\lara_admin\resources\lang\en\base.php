<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Backpack\Base Language Lines
    |--------------------------------------------------------------------------
    */

    'registration_closed'    => 'Registration is closed.',
    'no_email_column'        => 'Users do not have an associated email address.',
    'first_page_you_see'     => 'The first page you see after login',
    'login_status'           => 'Login status',
    'logged_in'              => 'You are logged in!',
    'toggle_navigation'      => 'Toggle navigation',
    'administration'         => 'ADMINISTRATION',
    'user'                   => 'USER',
    'logout'                 => 'Logout',
    'login'                  => 'Login',
    'register'               => 'Register',
    'name'                   => 'Name',
    'email_address'          => 'E-mail address',
    'password'               => 'Password',
    'old_password'           => 'Old password',
    'new_password'           => 'New password',
    'confirm_password'       => 'Confirm password',
    'remember_me'            => 'Remember me',
    'forgot_your_password'   => 'Forgot Your Password?',
    'reset_password'         => 'Reset Password',
    'send_reset_link'        => 'Send Password Reset Link',
    'click_here_to_reset'    => 'Click here to reset your password',
    'change_password'        => 'Change Password',
    'unauthorized'           => 'Unauthorized.',
    'dashboard'              => 'Dashboard',
    'handcrafted_by'         => 'Handcrafted by',
    'powered_by'             => 'Powered by',
    'my_account'             => 'My Account',
    'update_account_info'    => 'Update Account Info',
    'save'                   => 'Save',
    'cancel'                 => 'Cancel',
    'error'                  => 'Error',
    'success'                => 'Success',
    'old_password_incorrect' => 'Old password is incorrect.',
    'password_dont_match'    => 'Passwords do not match.',
    'password_empty'         => 'Make sure both password fields are filled out.',
    'password_updated'       => 'Password updated.',
    'account_updated'        => 'Account updated successfully.',
    'unknown_error'          => 'An unknown error has occured. Please try again.',
    'error_saving'           => 'Error while saving. Please try again.',

    'password_reset' => [
        'greeting' => 'Hello!',
        'subject'  => 'Reset Password Notification',
        'line_1'   => 'You are receiving this email because we received a password reset request for your account.',
        'line_2'   => 'Click the button below to reset your password:',
        'button'   => 'Reset Password',
        'notice'   => 'If you did not request a password reset, no further action is required.',
    ],

    'step'                 => 'Step',
    'confirm_email'        => 'Confirm Email',
    'choose_new_password'  => 'Choose New Password',
    'confirm_new_password' => 'Confirm new password',
];
