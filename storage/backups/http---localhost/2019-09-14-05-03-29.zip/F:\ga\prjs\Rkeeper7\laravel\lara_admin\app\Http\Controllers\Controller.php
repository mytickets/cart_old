<?php

namespace App\Http\Controllers;
use Auth;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

// use Illuminate\Support\Facades\Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


	public function __construct()
	{

	    $this->middleware(function ($request, $next) {
	        // view()->share('user', $request->user());
	        view()->share('user', Auth::guard('backpack')->user());
	        return $next($request);
	    });
	    // view()->share('user', auth()->user());
	    // view()->composer('*', function ($view) {
	    //     $view->with('user', auth()->user());
	    // });
	    // $this->account = Account::find(session('account_id'));
	}

// Setting a property on the controller that needs the session:
// If you need the same piece of information in all of your methods, you may opt to set it as a property on the controller:

}
