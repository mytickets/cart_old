{{-- registeredcount.blade.php --}}
<div>
    Total number of registered users for today is: {{ $count }}
</div>