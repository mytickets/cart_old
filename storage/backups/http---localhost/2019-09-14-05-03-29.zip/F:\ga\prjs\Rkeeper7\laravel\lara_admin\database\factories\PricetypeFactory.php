<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Pricetype;
use Faker\Generator as Faker;

$factory->define(Pricetype::class, function (Faker $faker) {
    return [
        //
    ];
});
