<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ntre;
use Faker\Generator as Faker;

$factory->define(ntre::class, function (Faker $faker) {
    return [
        //
    ];
});
