<?php

namespace App\Http\Controllers;

use App\Pricetype;
use Illuminate\Http\Request;

class PricetypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Pricetype  $pricetype
     * @return \Illuminate\Http\Response
     */
    public function show(Pricetype $pricetype)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Pricetype  $pricetype
     * @return \Illuminate\Http\Response
     */
    public function edit(Pricetype $pricetype)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Pricetype  $pricetype
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pricetype $pricetype)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Pricetype  $pricetype
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pricetype $pricetype)
    {
        //
    }
}
