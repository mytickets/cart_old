@extends('layouts.site')

@section('content')
	{{ $book->id }}: {{ $book->name }}
@endsection
